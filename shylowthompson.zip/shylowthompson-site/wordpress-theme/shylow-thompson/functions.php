<?php
function shylow_enqueue_assets() {
    wp_enqueue_style(
        'shylow-fonts',
        'https://fonts.googleapis.com/css2?family=Cormorant+Garamond:ital,wght@0,400;0,500;0,600;1,400&family=DM+Sans:ital,opsz,wght@0,9..40,300;0,9..40,400;0,9..40,500;1,9..40,300&display=swap',
        [],
        null
    );
    wp_enqueue_style('shylow-theme', get_stylesheet_uri(), ['shylow-fonts'], '1.0');
}
add_action('wp_enqueue_scripts', 'shylow_enqueue_assets');

// Strip unnecessary WordPress bloat from the frontend
add_action('wp_enqueue_scripts', function () {
    wp_dequeue_style('wp-block-library');
    wp_dequeue_style('wp-block-library-theme');
    wp_dequeue_style('global-styles');
    wp_dequeue_style('classic-theme-styles');
}, 100);

remove_action('wp_head', 'print_emoji_detection_script', 7);
remove_action('wp_print_styles', 'print_emoji_styles');
remove_action('wp_head', 'wp_generator');
remove_action('wp_head', 'wlwmanifest_link');
remove_action('wp_head', 'rsd_link');

add_filter('show_admin_bar', '__return_false');
