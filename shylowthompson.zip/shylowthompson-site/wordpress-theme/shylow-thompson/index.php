<!DOCTYPE html>
<html <?php language_attributes(); ?>>
<head>
  <meta charset="<?php bloginfo('charset'); ?>" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <meta name="description" content="Strategic consulting for bold businesses. Digital transformation, Web3, and technology strategy." />
  <?php wp_head(); ?>
</head>
<body <?php body_class(); ?>>

  <!-- NAV -->
  <nav>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="nav-logo">Shylow Thompson</a>
    <ul class="nav-links">
      <li><a href="#services">Services</a></li>
      <li><a href="#contact">Contact</a></li>
      <li><a href="#contact" class="btn btn-primary">Work With Me</a></li>
    </ul>
  </nav>

  <!-- HERO -->
  <section id="hero">
    <div class="hero-left">
      <p class="hero-eyebrow">Strategic Consulting</p>
      <h1 class="hero-headline">
        Consulting for<br /><em>bold</em><br />businesses.
      </h1>
      <p class="hero-sub">
        We help forward-thinking companies navigate digital transformation, embrace emerging technology, and build for what's next.
      </p>
      <div class="hero-actions">
        <a href="#services" class="btn btn-primary">View Services</a>
        <a href="#contact"  class="btn btn-outline">Get In Touch</a>
      </div>
      <div class="hero-stat-row">
        <div class="hero-stat">
          <span>10+</span>
          <p>Years Experience</p>
        </div>
        <div class="hero-stat">
          <span>50+</span>
          <p>Businesses Served</p>
        </div>
        <div class="hero-stat">
          <span>100%</span>
          <p>Results-Focused</p>
        </div>
      </div>
    </div>
    <div class="hero-right">
      <div class="hero-graphic">
        <div class="hero-graphic-content">
          <h3>Transform<br />your digital<br />future.</h3>
          <p>shylowthompson.com</p>
        </div>
      </div>
    </div>
  </section>

  <!-- SERVICES -->
  <section id="services">
    <div class="services-header fade-up">
      <div>
        <p class="section-label">What I Do</p>
        <h2 class="section-title">Services built for transformation.</h2>
      </div>
      <p class="section-desc">
        Every engagement is designed to move your business forward — with strategy grounded in reality and execution that delivers measurable results.
      </p>
    </div>
    <div class="services-grid">
      <div class="service-card fade-up">
        <p class="service-num">01</p>
        <div class="service-bar"></div>
        <h3 class="service-name">Digital Strategy</h3>
        <p class="service-desc">Map a clear path from where you are to where you need to be. We align your technology investments with business outcomes that actually matter.</p>
      </div>
      <div class="service-card fade-up">
        <p class="service-num">02</p>
        <div class="service-bar"></div>
        <h3 class="service-name">Web3 &amp; Blockchain</h3>
        <p class="service-desc">Navigate the frontier of decentralized technology. From token strategy to smart contract architecture — built for your business, not the hype.</p>
      </div>
      <div class="service-card fade-up">
        <p class="service-num">03</p>
        <div class="service-bar"></div>
        <h3 class="service-name">Systems &amp; Automation</h3>
        <p class="service-desc">Eliminate friction. Streamline operations and automate the work that doesn't need humans, so your team can focus on what does.</p>
      </div>
      <div class="service-card fade-up">
        <p class="service-num">04</p>
        <div class="service-bar"></div>
        <h3 class="service-name">Technology Roadmapping</h3>
        <p class="service-desc">Complex transformations require clear direction. We build the roadmap, identify the risks, and guide you through execution — step by step.</p>
      </div>
    </div>
  </section>

  <!-- CTA BAND -->
  <div id="cta-band" class="fade-up">
    <div>
      <p class="section-label">Ready to Begin</p>
      <h2 class="section-title">Let's build something bold together.</h2>
    </div>
    <a href="#contact" class="btn btn-gold" style="padding:1rem 2.5rem;font-size:0.9rem;white-space:nowrap;">
      Start a Conversation →
    </a>
  </div>

  <!-- CONTACT -->
  <section id="contact">
    <div class="contact-inner">
      <div class="fade-up">
        <p class="section-label">Get In Touch</p>
        <h2 class="section-title">Let's talk about your business.</h2>
        <div class="contact-meta">
          <p>Whether you're starting a transformation or looking to accelerate one already in motion, I'd love to hear about your goals.</p>
          <div class="contact-details">
            <div class="contact-item">
              <span>Email</span>
              <a href="mailto:admin@shylowthompson.com">admin@shylowthompson.com</a>
            </div>
            <div class="contact-item">
              <span>Availability</span>
              <a>Accepting new clients</a>
            </div>
          </div>
        </div>
      </div>

      <form class="contact-form fade-up" onsubmit="handleSubmit(event)">
        <div class="form-field">
          <label for="name">Your Name</label>
          <input type="text" id="name" placeholder="Full name" required />
        </div>
        <div class="form-field">
          <label for="email">Email Address</label>
          <input type="email" id="email" placeholder="you@company.com" required />
        </div>
        <div class="form-field">
          <label for="company">Company</label>
          <input type="text" id="company" placeholder="Your business" />
        </div>
        <div class="form-field">
          <label for="message">How can I help?</label>
          <textarea id="message" placeholder="Tell me about your goals..." required></textarea>
        </div>
        <p id="form-status">Message sent — I'll be in touch shortly.</p>
        <button type="submit" class="btn btn-primary" style="width:fit-content;">
          Send Message →
        </button>
      </form>
    </div>
  </section>

  <!-- FOOTER -->
  <footer class="site-footer">
    <p>© <?php echo date('Y'); ?> Shylow Thompson. All rights reserved.</p>
    <a href="mailto:admin@shylowthompson.com">admin@shylowthompson.com</a>
  </footer>

  <script>
    const io = new IntersectionObserver(entries => {
      entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('in'); });
    }, { threshold: 0.12 });
    document.querySelectorAll('.fade-up').forEach(el => io.observe(el));

    function handleSubmit(e) {
      e.preventDefault();
      const name    = document.getElementById('name').value;
      const email   = document.getElementById('email').value;
      const company = document.getElementById('company').value;
      const message = document.getElementById('message').value;
      const subject = encodeURIComponent('Inquiry from ' + name);
      const body    = encodeURIComponent(
        'Name: ' + name + '\nEmail: ' + email + '\nCompany: ' + company + '\n\n' + message
      );
      window.location.href =
        'mailto:admin@shylowthompson.com?subject=' + subject + '&body=' + body;
      document.getElementById('form-status').style.display = 'block';
      e.target.reset();
    }
  </script>

  <?php wp_footer(); ?>
</body>
</html>
