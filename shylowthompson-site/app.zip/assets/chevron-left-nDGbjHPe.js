import{U as o}from"./core-ACN954MB.js";import"./index-8WZbYVPO.js";import"./index.es-CwpWJJkT.js";import"./events-DQ172AOg.js";import"./index-DIwirM5T.js";const p=o`<svg fill="none" viewBox="0 0 16 16">
  <path
    fill="currentColor"
    fill-rule="evenodd"
    d="M11.04 1.46a1 1 0 0 1 0 1.41L5.91 8l5.13 5.13a1 1 0 1 1-1.41 1.41L3.79 8.71a1 1 0 0 1 0-1.42l5.84-5.83a1 1 0 0 1 1.41 0Z"
    clip-rule="evenodd"
  />
</svg>`;export{p as chevronLeftSvg};
